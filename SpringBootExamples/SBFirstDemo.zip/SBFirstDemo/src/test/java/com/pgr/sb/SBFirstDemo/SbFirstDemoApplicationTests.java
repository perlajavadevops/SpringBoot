package com.pgr.sb.SBFirstDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbFirstDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
